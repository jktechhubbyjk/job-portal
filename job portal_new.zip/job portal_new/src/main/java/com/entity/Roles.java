package com.entity;

public class Roles {

}
