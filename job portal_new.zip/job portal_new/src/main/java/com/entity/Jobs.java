package com.entity;

public class Jobs {
	private int jobId;
	private String title;
	private String description;
	private String category;
	private String location;
	private String status;
	private String pdate;
	public Jobs() {
	
	}
	public Jobs(String title, String description, String category, String location, String pdate) {
		this.title = title;
		this.description = description;
		this.category = category;
		this.location = location;
		this.pdate = pdate;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int id) {
		this.jobId = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	@Override
	public String toString() {
		return "Jobs [jobId=" + jobId + ", title=" + title + ", description=" + description + ", category=" + category
				+ ", location=" + location + ", status=" + status + ", pdate=" + pdate + "]";
	}
}
