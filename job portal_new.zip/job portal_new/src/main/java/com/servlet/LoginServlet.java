package com.servlet;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.User;
import com.utils.DatabaseConnection;



@WebServlet("/login")
public class LoginServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try {
			String em=req.getParameter("email");
			String ps=req.getParameter("password");
			User u=new User();
			HttpSession session=req.getSession();
			
		
			
			if (em.equals("admin@gmail.com") && ps.equals("admin@121")) {
				session.setAttribute("userobj",u);
				
				ResultSet rs= 	DatabaseConnection.initializeDatabase().createStatement().executeQuery("select role from roles where userid =101");
				String role ="";	
				while(rs.next()) {
						role = rs.getNString(1);
					}
				
				u.setRole("admin");
				if(role.equalsIgnoreCase("admin")) {
					resp.sendRedirect("admin.jsp");
				}if(role.equalsIgnoreCase("customer")) {
					resp.sendRedirect("customer.jsp");
				}
				
			}else {
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
 