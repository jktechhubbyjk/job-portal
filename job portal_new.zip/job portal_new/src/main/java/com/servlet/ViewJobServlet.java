package com.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.Jobs;
import com.utils.DatabaseConnection;

@WebServlet("/viewJobs")
public class ViewJobServlet extends HttpServlet{
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		ArrayList<Jobs> jobList = new ArrayList<Jobs>(); 
		Jobs job = new Jobs();
		HttpSession session;
		session= req.getSession();
		ResultSet rs;
		try {
			rs = DatabaseConnection.initializeDatabase().createStatement().executeQuery("select * from jobs");
			while(rs.next())
			{
				job.setJobId(rs.getInt(0));
				job.setTitle(rs.getString(1));
				job.setLocation(rs.getString(2));
				job.setCategory(rs.getString(3));
				job.setStatus(rs.getString(4));
				job.setDescription(rs.getString(5));
				jobList.add(job);
				System.out.println(jobList);
			}
			//req.setAttribute("jobList",jobList);
			req.getRequestDispatcher("view_jobs.jsp").forward(req, resp); 
			session.setAttribute("jobList", jobList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
	}
	

}
