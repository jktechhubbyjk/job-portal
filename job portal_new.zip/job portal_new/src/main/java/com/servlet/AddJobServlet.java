package com.servlet;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.utils.DatabaseConnection;

@WebServlet("/addjob")
public class AddJobServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String title = req.getParameter("title");
		String location = req.getParameter("Location");
		String category = req.getParameter("category");
		String status = req.getParameter("status");
		String desc = req.getParameter("desc");
		
		System.out.println("hellll");
		 String insertSql = "INSERT INTO jobs(title, location,category,status,description) values('" + title + "','"+ location +"','"+ category +"','"+ status +"','"+ desc +"')"; 
		
		
		try {
			PreparedStatement pst= DatabaseConnection.initializeDatabase().prepareStatement(insertSql);
			pst.execute();
			resp.sendRedirect("add_job.jsp");
		
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
 			e.printStackTrace();
		}
	}
}
